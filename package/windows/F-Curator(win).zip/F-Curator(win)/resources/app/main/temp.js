/**
 * Node script for temporary testing
 */

